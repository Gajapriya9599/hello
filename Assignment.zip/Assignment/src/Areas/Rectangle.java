package Areas;

public class Rectangle {

	public static void main(String[] args) {
		int length=5;
		float breadth= 6.4f;
	    float ans= length*breadth;
	    System.out.println("Area of Rectangle is " +length+ "*" + breadth+ "=" +ans+ "sqr units");
		// TODO Auto-generated method stub

	}

}
