package Areas;

public class Square {

	public static void main(String[] args) {
		int side=24;
		int ans=side*side;
		System.out.println("Area of square is " +side+ "*" +side+ "=" +ans+ "sqr units");
		// TODO Auto-generated method stub

	}

}
