package Areas;

public class Circle {

	public static void main(String[] args) {
		int rad=15;
		float rad1=11.56f;
		float cir=3.14f*rad*rad;
		float circ=3.14f*rad1*rad1;
		System.out.println("Area of circle is 3.14*" +rad+ "*" +rad+ "=" +cir+ "sqr units");
		System.out.println("Area of circle is 3.14*" +rad1+ "*" +rad1+ "=" +circ+ "sqr units");
		// TODO Auto-generated method stub

	}

}
