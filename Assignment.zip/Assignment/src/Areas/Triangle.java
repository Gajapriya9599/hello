package Areas;

public class Triangle {

	public static void main(String[] args) {
		float breadth,length,base,ans;
		breadth=4.65f;
		length=6.56f;
		base=4.56f;
		ans=1/2f*(breadth*length*base);
		System.out.println("Area of Triangle 0.5*" +breadth+ "*" +length+ 
				"*" +base+ " is " +ans+ "sqrunits");
		
		
		// TODO Auto-generated method stub

	}

}
